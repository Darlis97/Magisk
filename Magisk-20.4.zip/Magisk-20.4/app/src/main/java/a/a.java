package a;

import com.topjohnwu.signing.BootSigner;

public class a {

    public static void main(String[] args) throws Exception {
        BootSigner.main(args);
    }
}
