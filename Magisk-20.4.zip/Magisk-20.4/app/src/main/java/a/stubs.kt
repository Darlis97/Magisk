package a

import com.topjohnwu.magisk.core.App
import com.topjohnwu.magisk.core.GeneralReceiver
import com.topjohnwu.magisk.core.SplashActivity
import com.topjohnwu.magisk.core.download.DownloadService
import com.topjohnwu.magisk.legacy.flash.FlashActivity
import com.topjohnwu.magisk.legacy.surequest.SuRequestActivity
import com.topjohnwu.magisk.ui.MainActivity

class b : MainActivity()

class c : SplashActivity()

class e : App {
    constructor() : super()
    constructor(o: Any) : super(o)
}

class f : FlashActivity()

class h : GeneralReceiver()

class j : DownloadService()

class m : SuRequestActivity()
