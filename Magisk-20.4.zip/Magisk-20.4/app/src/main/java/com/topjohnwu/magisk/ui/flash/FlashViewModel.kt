package com.topjohnwu.magisk.ui.flash

import com.topjohnwu.magisk.ui.base.BaseViewModel

class FlashViewModel : BaseViewModel()
