package com.topjohnwu.magisk.model.events

class SimpleViewEvent(
    val event: Int
) : ViewEvent()