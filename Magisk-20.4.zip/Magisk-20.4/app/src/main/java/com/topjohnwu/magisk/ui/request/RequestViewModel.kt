package com.topjohnwu.magisk.ui.request

import com.topjohnwu.magisk.ui.base.BaseViewModel

class RequestViewModel : BaseViewModel()
