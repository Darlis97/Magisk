package com.topjohnwu.magisk.ui

interface ReselectionTarget {

    fun onReselected()

}
