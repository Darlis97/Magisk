# v7.5.1
- Fix toggling app components in MagiskHide screen
- Update translations
